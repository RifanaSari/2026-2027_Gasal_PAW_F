-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 01, 2026 at 05:04 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualan`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id` int NOT NULL,
  `kode_barang` varchar(30) DEFAULT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `stok` int NOT NULL,
  `supplier_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id`, `kode_barang`, `nama_barang`, `harga`, `stok`, `supplier_id`) VALUES
(1, 'BRG001', 'Buku Tulis', '5000.00', 100, 1),
(2, 'BRG002', 'Pulpen', '3000.00', 150, 2),
(3, 'BRG003', 'Pensil', '2000.00', 200, 3),
(4, 'BRG004', 'Penghapus', '1500.00', 100, 4),
(5, 'BRG005', 'Penggaris', '4000.00', 80, 5),
(6, 'BRG006', 'Spidol', '7000.00', 60, 6),
(7, 'BRG007', 'Buku Gambar', '8000.00', 50, 7),
(8, 'BRG008', 'Stabilo', '6000.00', 75, 8),
(9, 'BRG009', 'Map Plastik', '2500.00', 120, 9),
(10, 'BRG010', 'Tempat Pensil', '15000.00', 40, 10);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` char(1) DEFAULT NULL,
  `telp` varchar(20) DEFAULT NULL,
  `alamat` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id`, `nama`, `jenis_kelamin`, `telp`, `alamat`) VALUES
(1, 'Andi Saputra', 'L', '081234567801', 'Bangkalan'),
(2, 'Siti Aminah', 'P', '081234567802', 'Surabaya'),
(3, 'Budi Santoso', 'L', '081234567803', 'Sampang'),
(4, 'Dewi Lestari', 'P', '081234567804', 'Pamekasan'),
(5, 'Rizky Pratama', 'L', '081234567805', 'Sumenep'),
(6, 'Putri Amelia', 'P', '081234567806', 'Surabaya'),
(7, 'Fajar Nugraha', 'L', '081234567807', 'Bangkalan'),
(8, 'Nadia Safitri', 'P', '081234567808', 'Gresik'),
(9, 'Agus Setiawan', 'L', '081234567809', 'Sidoarjo'),
(10, 'Rina Oktaviani', 'P', '081234567810', 'Lamongan');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int NOT NULL,
  `waktu_bayar` datetime DEFAULT NULL,
  `total` decimal(12,2) DEFAULT NULL,
  `metode` enum('Tunai','Transfer','EDC') DEFAULT NULL,
  `transaksi_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `waktu_bayar`, `total`, `metode`, `transaksi_id`) VALUES
(1, '2026-10-01 09:05:00', '10000.00', 'Tunai', 1),
(2, '2026-10-02 10:35:00', '9000.00', 'Transfer', 2),
(3, '2026-10-03 11:05:00', '10000.00', 'EDC', 3),
(4, '2026-10-04 13:20:00', '6000.00', 'Tunai', 4),
(5, '2026-10-05 14:05:00', '8000.00', 'Transfer', 5),
(6, '2026-10-06 15:35:00', '14000.00', 'EDC', 6),
(7, '2026-10-07 09:50:00', '8000.00', 'Tunai', 7),
(8, '2026-10-08 10:05:00', '12000.00', 'Transfer', 8),
(9, '2026-10-09 12:05:00', '10000.00', 'EDC', 9),
(10, '2026-10-10 16:05:00', '15000.00', 'Tunai', 10);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL,
  `telp` varchar(20) DEFAULT NULL,
  `alamat` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `nama`, `telp`, `alamat`) VALUES
(1, 'PT Sumber Makmur', '081111111101', 'Surabaya'),
(2, 'CV Berkah Jaya', '081111111102', 'Bangkalan'),
(3, 'PT Maju Bersama', '081111111103', 'Sidoarjo'),
(4, 'CV Mitra Sejahtera', '081111111104', 'Gresik'),
(5, 'PT Indo Niaga', '081111111105', 'Malang'),
(6, 'CV Sinar Abadi', '081111111106', 'Pamekasan'),
(7, 'PT Karya Utama', '081111111107', 'Madura'),
(8, 'CV Jaya Sentosa', '081111111108', 'Surabaya'),
(9, 'PT Aneka Produk', '081111111109', 'Mojokerto'),
(10, 'CV Sukses Mandiri', '081111111110', 'Lamongan');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int NOT NULL,
  `waktu_transaksi` datetime DEFAULT NULL,
  `keterangan` text,
  `total` decimal(12,2) DEFAULT NULL,
  `pelanggan_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `waktu_transaksi`, `keterangan`, `total`, `pelanggan_id`) VALUES
(1, '2026-10-01 09:00:00', 'Pembelian alat tulis', '10000.00', 1),
(2, '2026-10-02 10:30:00', 'Pembelian perlengkapan sekolah', '9000.00', 2),
(3, '2026-10-03 11:00:00', 'Pembelian alat tulis', '10000.00', 3),
(4, '2026-10-04 13:15:00', 'Pembelian perlengkapan kantor', '6000.00', 4),
(5, '2026-10-05 14:00:00', 'Pembelian alat tulis', '8000.00', 5),
(6, '2026-10-06 15:30:00', 'Pembelian perlengkapan kantor', '14000.00', 6),
(7, '2026-10-07 09:45:00', 'Pembelian buku gambar', '8000.00', 7),
(8, '2026-10-08 10:00:00', 'Pembelian alat tulis', '12000.00', 8),
(9, '2026-10-09 12:00:00', 'Pembelian perlengkapan sekolah', '10000.00', 9),
(10, '2026-10-10 16:00:00', 'Pembelian tempat pensil', '15000.00', 10);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_detail`
--

CREATE TABLE `transaksi_detail` (
  `transaksi_id` int NOT NULL,
  `barang_id` int NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `qty` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transaksi_detail`
--

INSERT INTO `transaksi_detail` (`transaksi_id`, `barang_id`, `harga`, `qty`) VALUES
(1, 1, '5000.00', 2),
(2, 2, '3000.00', 3),
(3, 3, '2000.00', 5),
(4, 4, '1500.00', 4),
(5, 5, '4000.00', 2),
(6, 6, '7000.00', 2),
(7, 7, '8000.00', 1),
(8, 8, '6000.00', 2),
(9, 9, '2500.00', 4),
(10, 10, '15000.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` text,
  `hp` varchar(20) DEFAULT NULL,
  `level` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `alamat`, `hp`, `level`) VALUES
(1, 'admin', 'admin123', 'Administrator', 'Bangkalan', '082222222201', 'admin'),
(2, 'kasir01', 'kasir123', 'Dina Putri', 'Surabaya', '082222222202', 'kasir'),
(3, 'kasir02', 'kasir123', 'Rudi Hartono', 'Sampang', '082222222203', 'kasir'),
(4, 'kasir03', 'kasir123', 'Maya Sari', 'Pamekasan', '082222222204', 'kasir'),
(5, 'admin02', 'admin123', 'Fajar Rizki', 'Gresik', '082222222205', 'admin'),
(6, 'kasir04', 'kasir123', 'Nina Amelia', 'Malang', '082222222206', 'kasir'),
(7, 'kasir05', 'kasir123', 'Agus Wijaya', 'Bangkalan', '082222222207', 'kasir'),
(8, 'kasir06', 'kasir123', 'Sinta Dewi', 'Sidoarjo', '082222222208', 'kasir'),
(9, 'admin03', 'admin123', 'Budi Santoso', 'Mojokerto', '082222222209', 'admin'),
(10, 'kasir07', 'kasir123', 'Rina Safitri', 'Lamongan', '082222222210', 'kasir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaksi_id` (`transaksi_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pelanggan_id` (`pelanggan_id`);

--
-- Indexes for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD PRIMARY KEY (`transaksi_id`,`barang_id`),
  ADD KEY `barang_id` (`barang_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`);

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`pelanggan_id`) REFERENCES `pelanggan` (`id`);

--
-- Constraints for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD CONSTRAINT `transaksi_detail_ibfk_1` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`),
  ADD CONSTRAINT `transaksi_detail_ibfk_2` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
